package com.mygame.inputs;

import com.mygame.engine.core.GameStateManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Function;
import javax.swing.JComponent;

// this sends all input DisplaySurface -> InputHandler (logical coordinates) -> GameStateManager -> current state
public class InputHandler extends MouseAdapter implements KeyListener {
    private final GameStateManager stateManager;
    private final Function<MouseEvent, MouseEvent> mouseEventTranslator;
    private final Runnable toggleFullscreen;
    private Runnable toggleFpsCounter = () -> { };

    public InputHandler(JComponent component, GameStateManager stateManager,
                        Function<MouseEvent, MouseEvent> mouseEventTranslator,
                        Runnable toggleFullscreen) {
        this.stateManager = stateManager;
        this.mouseEventTranslator = mouseEventTranslator;
        this.toggleFullscreen = toggleFullscreen;
        component.addMouseListener(this);
        component.addMouseMotionListener(this);
        component.addMouseWheelListener(this);
        component.addKeyListener(this);
    }

    @Override
    public void mousePressed(MouseEvent event) {
        stateManager.mousePressed(mouseEventTranslator.apply(event));
    }

    @Override
    public void mouseReleased(MouseEvent event) {
        stateManager.mouseReleased(mouseEventTranslator.apply(event));
    }

    @Override
    public void mouseMoved(MouseEvent event) {
        stateManager.mouseMoved(mouseEventTranslator.apply(event));
    }

    @Override
    public void mouseDragged(MouseEvent event) {
        stateManager.mouseMoved(mouseEventTranslator.apply(event));
    }

    @Override
    public void mouseWheelMoved(java.awt.event.MouseWheelEvent event) {
        stateManager.mouseWheelMoved(event);
    }

    @Override
    public void mouseEntered(MouseEvent event) {
        event.getComponent().requestFocusInWindow();
    }

    @Override
    public void keyPressed(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.VK_F11) {
            toggleFullscreen.run();
            return;
        }
        if (event.getKeyCode() == KeyEvent.VK_F3) {
            toggleFpsCounter.run();
            return;
        }
        stateManager.keyPressed(event);
    }

    public void setToggleFpsCounter(Runnable toggleFpsCounter) {
        this.toggleFpsCounter = toggleFpsCounter;
    }

    @Override
    public void keyReleased(KeyEvent event) {
        stateManager.keyReleased(event);
    }

    @Override
    public void keyTyped(KeyEvent event) {
    }
}
