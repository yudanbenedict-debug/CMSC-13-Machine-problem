package com.mygame.ui;

import com.mygame.engine.core.GameStateManager;
import com.mygame.engine.core.Sfx;
import java.util.List;

public class CreditsState extends InfoState {
    public CreditsState(GameStateManager stateManager) {
        super(stateManager, "CREDITS", List.of(
            InfoBlock.heading("Created By"),
            InfoBlock.body("Francis Kyle A.S."),
            InfoBlock.body("Dan Benedict G.Y."),
            InfoBlock.heading("Art Designs"),
            InfoBlock.body("Lorenzo Badinas"),
            InfoBlock.heading("Original Game Creators"),
            InfoBlock.body("Valve (Deadlock)"),
            InfoBlock.heading("Special Thanks To"),
            InfoBlock.body("Pocari Sweat"),
            InfoBlock.gap(10),
            InfoBlock.subheading("CMSC 13: Survey of Programming Paradigms"),
            InfoBlock.body("University of the Philippines Tacloban College")
        ), Sfx.CREDIT_MENU_ONSELECT);
    }
}
